<h1>Bienvenido a nuestra plataforma, {{ $user->name }}!</h1>

<p>Gracias por registrarte en nuestra plataforma. Estamos felices de tenerte con nosotros.</p>

<p>Si tienes alguna pregunta o necesitas ayuda, no dudes en contactarnos. Estaremos encantados de ayudarte.</p>

<p>Esperamos que tengas una excelente experiencia de compra.</p>

<p>Saludos,</p>
<p>MyS Plantas y Suculentas Chillán</p>