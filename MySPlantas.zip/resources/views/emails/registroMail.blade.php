<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>  
        <h1>Bienvenido {!! $nombre !!}</h1>
        <h1> Gracias por Registrarte en MyS Chillan </h1>
        <p>Ingresa con tu cuenta para comenzar a utilizar el sistema de venta en linea</p>
        <hr/>
        MyS Plantas y Suculentas Chillan
        <button><a href="http://127.0.0.1:8000"></a>Ingresar</button>
        <hr>
</body>
</html>