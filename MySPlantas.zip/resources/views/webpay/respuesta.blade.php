@extends('layaouts.master')

@section('content')
{{dd($datos)}}
@endsection