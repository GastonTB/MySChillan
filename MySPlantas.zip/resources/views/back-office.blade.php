
@extends('layaouts.master')

@section('content')
    
    <div class="grid grid-cols-7 mt-10 mb-10">
        <div class="lg:col-start-2 md:col-span-7 lg:col-span-5 md:px-5 lg:px-0">
            <div class="grid grid-cols-6 gap-4">
                <div class="lg:col-span-2 md:col-span-3">
                    <div class="">
                        <div class="bg-lime-500 text-white text-lg font-semibold p-1 pl-3 uppercase">
                            Productos
                        </div>
                        <div class="p-1 pl-3 border-2">
                            <ul class="list-disc pl-4 space-y-3 mt-3">
                                <li class="hover:text-lime-500 hover:font-semibold cursor-pointer">
                                    <a href="{{route('crearproducto')}}">Crear Nuevo Producto</a>
                                </li>
                                <li class="hover:text-lime-500 hover:font-semibold cursor-pointer">
                                    <a href="{{route('listado-productos')}}">Ver Listado de Productos</a>
                                </li>
                                <li class="hover:text-lime-500 hover:font-semibold cursor-pointer">
                                    <a href="{{route('sin-stock')}}">Ver Productos Sin Stock</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="lg:col-span-2 md:col-span-3">
                    <div class="">
                        <div class="bg-lime-500 text-white text-lg font-semibold p-1 pl-3 uppercase">
                            Ofertas
                        </div>
                        <div class="p-1 pl-3 border-2">
                            <ul class="list-disc pl-4 space-y-3 mt-3">
                                <li class="hover:text-lime-500 hover:font-semibold cursor-pointer">
                                    <a href="{{route('mostrarOfertas')}}">
                                        Ver Todas las Ofertas
                                    </a>
                                </li>
                                <li class="hover:text-lime-500 hover:font-semibold cursor-pointer">
                                    <a href="{{route('mostrarOfertasActivas')}}">
                                        Ver Ofertas Activas
                                    </a>
                                </li>
                                <li class="hover:text-lime-500 hover:font-semibold cursor-pointer">
                                    <a href="{{route('mostrarOfertasFuturas')}}">
                                        Ver Ofertas Futuras
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="lg:col-span-2 md:col-span-3">
                    <div class="">
                        <div class="bg-lime-500 text-white text-lg font-semibold p-1 pl-3 uppercase">
                            Compras
                        </div>
                        <div class="p-1 pl-3 border-2">
                            <ul class="list-disc pl-4 space-y-3 mt-3">
                                <li class="pendiente hover:text-lime-500 hover:font-semibold cursor-pointer">Ver Compras Realizadas</li>
                                <li class="pendiente hover:text-lime-500 hover:font-semibold cursor-pointer">Compras con Retiro en Tienda</li>
                                <li class="pendiente hover:text-lime-500 hover:font-semibold cursor-pointer">Compras con Envio a Domicílio</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="xl:grid xl:grid-cols-6 gap-4 mt-5 mb-10">
                <div class="col-span-3">
                    <div class="flex justify-center">
                        <p class="text-lg font-black">
                            Productos Por Enviar
                        </p>
                    </div>
                    <div class="md:flex md:justify-center mt-5">
                        <table class="overflow-x-auto">
                            <thead>
                                <tr class="bg-lime-500 text-white uppercase font-semibold">
                                    <th class="hidden">ID</th>
                                    <th class="px-4 py-1">Nombre</th>
                                    <th class="px-4 py-1">Total</th>
                                    <th class="px-4 py-1">Fecha</th>
                                    <th class="px-4 py-1">Telefono</th>
                                    <th class="px-4 py-1">Región</th>
                                    <th class="px-4 py-1">Direccion</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($porEnviar as $enviar)
                                    <tr id="{{$enviar->id}}" class="hover:font-semibold hover:text-lime-500 enviar">
                                        
                                            <td class="border px-4 py-1">
                                                <a href="{{route('compra', $enviar->id)}}">
                                                <p>
                                                {{ $enviar->user->name }}
                                            </p>
                                                <p>
                                                    {{$enviar->user->metauser->apellido_paterno}}
                                                </p>
                                            </a>

                                                </td>
        
                                                <td class="border px-4 py-1">
                                                    ${{number_format(
                                                        $enviar->total,
                                                        0,
                                                        ',',
                                                        '.'
                                                    )}}
                                                </td>
                                                <td class="border px-4 py-1">
                                                    {{ date('d-m-Y', strtotime($enviar->created_at)) }}
                                                </td>
                                                <td class="border px-4 py-1">{{ $enviar->telefono }}</td>
                                                <td class="border px-4 py-1">{{ $enviar->user->metauser->comuna_id }}</td>
                                                <td class="border px-4 py-1">{{ $enviar->direccion }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <div class="py-3">
                                {{ $porEnviar->links() }}
                            </div>
                        </table>
                    </div>
                </div>
                <div class="col-span-3 mt-10 xl:mt-0">
                    <div class="flex justify-center mb-5">
                        <p class="text-lg font-black">
                            Productos Por Retirar
                        </p>
                    </div>
                    <div class="flex justify-center">
                        <table class="">
                            <thead class="border">
                                <tr class="bg-lime-500 text-white uppercase font-semibold">
                                    <th class="px-4 py-1">Nombre</th>
                                    <th class="px-4 py-1">Total</th>
                                    <th class="px-4 py-1">Fecha</th>
                                    <th class="px-4 py-1">Telefono</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($porRetirar as $retirar)
                                    <tr class="hover:font-semibold hover:text-lime-500 enviar">
                                        <td class="border px-4 py-1">
                                            <a href="{{route('compra', $retirar->id)}}">
                                                <p>
                                                {{ $retirar->user->name }}
                                            </p>
                                                <p>
                                                    {{$retirar->user->metauser->apellido_paterno}}
                                                </p>
                                            </a>
                                        </td>
                                        <td class="border px-4 py-1">
                                            ${{number_format(
                                                $retirar->total,
                                                0,
                                                ',',
                                                '.'
                                            )}}
                                        </td>
                                        <td class="border px-4 py-1">
                                            {{ date('d-m-Y', strtotime($retirar->created_at)) }}
                                        </td>
                                        <td class="border px-4 py-1">{{ $retirar->telefono }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <div class="py-3">
                                {{ $porRetirar->links() }}
                            </div>
                        </table>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-6 gap-4 mt-5">
                <div class="lg:col-span-2 md:col-span-3">
                    <p class="uppercase text-lg font-black flex justify-center">
                        Productos Por Categoría
                    </p>
                    {{-- pie chart to show product by categoria --}}
                    <div class="flex justify-center">
                        <canvas id="myChart2" width="400" height="400"></canvas>
                    </div>
                </div>
                <div class="lg:col-span-2 md:col-span-3">
                    <p class="uppercase text-lg font-black flex justify-center">
                        Ventas Por Mes
                    </p>
                    <div class="flex justify-center">
                        <canvas id="myChart3" width="400" height="400"></canvas>
                    </div>
                </div>
                <div class="lg:col-span-2 md:col-span-3">
                    <p class="uppercase text-lg font-black flex justify-center">
                        Visitas por mes
                    </p>
                    <div class="flex justify-center">
                        <canvas id="myChart4" width="400" height="400"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

@section('js')
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.0.1/dist/chart.umd.min.js"></script>
    {{-- import sweet alert --}}
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function(){
            $('.pendiente').on('click', function(){
                //swalfire
                Swal.fire({
                    title: 'Lo Sentimos',
                    text: "Página en Construcción",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Aceptar'
                })
               
            });
        });
    </script>
    <script>
        const ctx2 = document.getElementById('myChart2');
        var categorias = [];
        var cantidad2 = [];
        @foreach ($array as $categoria)
            categorias.push("{{$categoria->nombre_categoria}}");
            cantidad2.push("{{$categoria->productos}}");
        @endforeach
        new Chart(ctx2, {
            type: 'pie',
          data: {
            labels: categorias,
            datasets: [{
              label: 'Productos',
              data: cantidad2,
              borderWidth: 0
            }]
          },
          options: {
               
          }
        });
    </script>
    <script>
        var ctx = document.getElementById('myChart3');
        var meses = [];
        var cantidad3 = [];
        @foreach($array6 as $item)
            meses.push("{{$item["mes"]}}");
        @endforeach
        @foreach($array6 as $item)
            cantidad3.push("{{$item["cantidad"]}}");
        @endforeach
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: meses,
                datasets: [{
                label: 'Cantidad de Ventas',
                data: cantidad3,
                borderWidth: 0
                }]
            },
            options: {
                
                

                
            }
        });
    </script>
    <script>
        var ctx = document.getElementById('myChart4');
        var meses2 = [];
        var cantidad4 = [];
        @foreach($array7 as $item)
            meses2.push("{{$item["mes"]}}");
        @endforeach
        @foreach($array7 as $item)
            cantidad4.push("{{$item["cantidad"]}}");
        @endforeach
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: meses2,
                datasets: [{
                label: 'Cantidad de Visitas',
                data: cantidad4,
                borderWidth: 0
                }]
            },
            options: {
                
                
               

                
            }
        });
    </script>

@endsection
@endsection