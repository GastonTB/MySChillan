<div>
    <div class="flex justify-center">
        <div  class="inline-flex items-center justify-center w-10 h-10 mr-2 text-black transition-colors duration-150 bg-lime-500 rounded-full focus:shadow-outline hover:bg-lime-500 hover:text-white">
            <i class="fa-solid fa-phone fa-xl"></i>
        </div>
        <div>
            <p class="text-lg md:text-xl md:font-black">+569 66 419 506</p>
            <div class="flex justify-start">
                <p class="text-sm md:text-xl">Contacto</p>
            </div>
        </div>
    </div>
</div>