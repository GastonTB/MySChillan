<div>
    <div class="relative select-none">
        <img src="img/hero/banner.jpg" alt="">
        <div class="md:hidden lg:hidden xl:hidden">
            <p class="borde absolute top-0 left-5 text-3xl font-black text-lime-500" style="text-shadow: #E5E9F0 1px 0px 0px, #E5E9F0 0.540302px 0.841471px 0px, #E5E9F0 -0.416147px 0.909297px 0px, rgb(255, 255, 255) -0.989992px 0.14112px 0px, rgb(255, 255, 255) -0.653644px -0.756802px 0px, rgb(255, 255, 255) 0.283662px -0.958924px 0px, rgb(255, 255, 255) 0.96017px -0.279415px 0px;">Jardin MyS</p>
            <p class="borde absolute top-10 left-5 text-3xl nssm:text-4xl font-black text-yellow-500" style="text-shadow: #E5E9F0 1px 0px 0px, #E5E9F0 0.540302px 0.841471px 0px, #E5E9F0 -0.416147px 0.909297px 0px, rgb(255, 255, 255) -0.989992px 0.14112px 0px, rgb(255, 255, 255) -0.653644px -0.756802px 0px, rgb(255, 255, 255) 0.283662px -0.958924px 0px, rgb(255, 255, 255) 0.96017px -0.279415px 0px;">Plantas y Suculentas</p>
            <a href="{{route('filtrados',['id' => 9, 'minimo' => 0, 'maximo' => 100000, 'orden' => 1, 'nombre' => '999'])}}" class="absolute btn-primary left-5 top-2/3">
                Comprar
            </a>
        </div>
        <div class="hidden md:block lg:hidden">
            <p class="borde absolute top-5 left-5 text-2xl md:text-5xl font-black text-lime-500" style="text-shadow: #E5E9F0 1px 0px 0px, #E5E9F0 0.540302px 0.841471px 0px, #E5E9F0 -0.416147px 0.909297px 0px, rgb(255, 255, 255) -0.989992px 0.14112px 0px, rgb(255, 255, 255) -0.653644px -0.756802px 0px, rgb(255, 255, 255) 0.283662px -0.958924px 0px, rgb(255, 255, 255) 0.96017px -0.279415px 0px;">Jardin MyS</p>
            <p class="borde absolute top-3/12 left-5 text-2xl md:text-7xl font-black text-yellow-500" style="text-shadow: #E5E9F0 1px 0px 0px, #E5E9F0 0.540302px 0.841471px 0px, #E5E9F0 -0.416147px 0.909297px 0px, rgb(255, 255, 255) -0.989992px 0.14112px 0px, rgb(255, 255, 255) -0.653644px -0.756802px 0px, rgb(255, 255, 255) 0.283662px -0.958924px 0px, rgb(255, 255, 255) 0.96017px -0.279415px 0px;">Plantas y Suculentas</p>
            <a href="{{route('filtrados',['id' => 9, 'minimo' => 0, 'maximo' => 100000, 'orden' => 1, 'nombre' => '999'])}}" class="absolute btn-primary left-1/10 top-9/12">
                Comprar
            </a>
        </div>
         <div class="hidden lg:block">
            <p class="borde absolute top-5 left-5 text-2xl md:text-5xl font-black text-lime-500" style="text-shadow: #E5E9F0 1px 0px 0px, #E5E9F0 0.540302px 0.841471px 0px, #E5E9F0 -0.416147px 0.909297px 0px, rgb(255, 255, 255) -0.989992px 0.14112px 0px, rgb(255, 255, 255) -0.653644px -0.756802px 0px, rgb(255, 255, 255) 0.283662px -0.958924px 0px, rgb(255, 255, 255) 0.96017px -0.279415px 0px;">Jardin MyS</p>
            <p class="borde absolute top-3/12 left-5 text-2xl md:text-7xl font-black text-yellow-500" style="text-shadow: #E5E9F0 1px 0px 0px, #E5E9F0 0.540302px 0.841471px 0px, #E5E9F0 -0.416147px 0.909297px 0px, rgb(255, 255, 255) -0.989992px 0.14112px 0px, rgb(255, 255, 255) -0.653644px -0.756802px 0px, rgb(255, 255, 255) 0.283662px -0.958924px 0px, rgb(255, 255, 255) 0.96017px -0.279415px 0px;">Plantas y Suculentas</p>
            <a href="{{route('filtrados',['id' => 9, 'minimo' => 0, 'maximo' => 100000, 'orden' => 1, 'nombre' => '999'])}}" class="absolute btn-primary left-1/4 top-9/12">
                Comprar
            </a>
        </div>
    </div>
</div>