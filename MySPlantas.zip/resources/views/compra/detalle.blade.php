@extends('layaouts.master')

@section('content')
    <div class="grid grid-cols-4 mt-10 text-gray-700">
        <div class="col-start-2 col-span-2">
            <div class="grid grid-cols-2 bg-gray-100 p-5 rounded-md">
                <div class="flex justify-center col-span-2 mb-10">
                    <p class="text-2xl font-bold">
                        Detalles de la Compra N° {{$ordenCompra->id}}
                    </p>
                </div>
                <div>
                    <div class="flex justify-center mb-5">
                        <p class="text-lg font-semibold">
                            Datos del Cliente
                        </p>
                    </div>
                    <div class="flex justify-center pl-5">
                        <ul class="list-disc space-y-2">
                            <li class="break-all ">
                                <div class="flex space-x-1">
                                    <p class="font-semibold">
                                        Nombre:
                                    </p>      
                                    <p>
                                    <p class="flex">
                                        @if((strlen($usuario->name) + strlen($meta->apellido_paterno) + strlen($meta->apellido_materno)) > 30)
                                            {{substr($usuario->name, 0, 10)}} {{substr($meta->apellido_paterno, 0, 10)}} {{substr($meta->apellido_materno, 0, 10)}}
                                        @else
                                            {{$usuario->name}} {{$meta->apellido_paterno}} {{$meta->apellido_materno}}
                                        @endif
                                    </p>
                                  
                           
                                </div>
                            </li>
                            <li>
                                <div class="flex space-x-1">
                                    <p class="font-semibold">
                                        Email:
                                    </p>      
                                    <p>
                                    <p class="flex">
                                        {{$ordenCompra->correo}}
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="flex space-x-1">
                                    <p class="font-semibold">
                                        Teléfono: 
                                    </p>      
                                    <p>
                                    <p class="flex">
                                        {{$ordenCompra->telefono}}
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="flex space-x-1">
                                    <p class="font-semibold">
                                        Región: 
                                    </p>      
                                    <p>
                                    <p class="flex">
                                        {{$region->nombre_region}}
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="flex space-x-1">
                                    <p class="font-semibold">
                                        Comuna: 
                                    </p>      
                                    <p>
                                    <p class="flex">
                                        {{$comuna->nombre_comuna}}
                                    </p>
                                </div>
                            </li>
                            <li>
                                <div class="flex space-x-1">
                                    <p class="font-semibold">
                                        Dirección: 
                                    </p>      
                                    <p>
                                    <p class="flex">
                                        {{$ordenCompra->direccion}}
                                    </p>
                                </div>
                            </li>

                        </ul>
                    </div>
                </div>
                <div>
                    <div class="flex justify-center mb-5">
                        <p class="text-lg font-semibold">
                            Datos de la Compra
                        </p>
                    </div>
                    <div class="flex justify-center">
                        <div>
                            <ul class="space-y-2 list-disc">
                                <li>
                                    <div class="flex space-x-1">
                                        <p class="font-semibold">
                                            Fecha de Compra:
                                        </p>      
                                        <p>
                                        <p class="flex">
                                            {{date('d-m-Y', strtotime($ordenCompra->created_at))}}
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <div class="flex space-x-1">
                                        <p class="font-semibold">
                                            Tipo de Envío: 
                                        </p>
                                        <p>
                                        @if($ordenCompra->envio == 1)
                                            Retiro en Tienda
                                        @else
                                            Envío a Domicilio
                                        @endif
                                        </p>
                                    </div>
                                </li>
                                <li>
                                    <p class="font-semibold">
                                        @if($ordenCompra->envio == 1)
                                            Retirado:
                                            @if($ordenCompra->estado_retiro == 0)
                                                No
                                            @else
                                                Si
                                            @endif
                                        @else
                                            Enviado:
                                            @if($ordenCompra->estado_envio == 0)
                                                No
                                            @else
                                                Si
                                            @endif
                                        @endif
                                    </p>
                                </li>
                                <li>
                                    <div class="flex space-x-1">
                                        <p class="font-semibold">
                                            Total de Compra: 
                                        </p>
                                        <p>
                                            {{-- numberformat --}}
                                            ${{number_format($ordenCompra->total, 0, ',', '.')}}
                                        </p>
                                    </div>
                                </li>
                            </ul>
                            <div class="grid grid-cols-2 mt-3">
                                <div>
                                    <p class="font-semibold">
                                        Productos
                                    </p>
                                    <div class="mt-2">
                                        @foreach ($productos as $producto)
                                            <div class="flex space-x-1">
                                                <p class="font-medium">
                                                    {{$producto->nombre_producto}}
                                                </p> 
                                                <p class="text-sm">x</p>
                                                 <p>
                                                    {{$producto->pivot->cantidad_orden_compra}}
                                                </p>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="flex justify-end">
                                    <div>
                                        <p class="font-semibold">
                                            Precios
                                        </p>
                                        <div class="mt-2">
                                            @foreach ($productos as $producto)
                                            <p class="">
                                                ${{number_format($producto->pivot->precio_orden_compra, 0, ',', '.')}}
                                            </p>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-span-2">
                    <div class="flex justify-center mt-10">
                        <form id="formulario" method="POST" action="{{route('editarCompra', $ordenCompra->id)}}">
                            @csrf
                            <button type="button" class="btn-primary">
                                @if($ordenCompra->envio == 1)
                                    @if($ordenCompra->estado_retiro == 0)
                                        Retirar
                                    @else
                                        Retirado
                                    @endif
                                @else
                                    @if($ordenCompra->estado_retiro == 0)
                                        Enviar
                                    @else
                                        Enviado
                                    @endif
                                @endif
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        $('.btn-primary').click(function(){
            @if($ordenCompra->estado_retiro == 0)
            Swal.fire({
                title: '¿Estas Seguro?',
                text: "Marcarás este pedido como Enviado/Retirado",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, ¡Estoy seguro!'
            }).then((result) => {
                if (result.isConfirmed) {
                    
                    $('#formulario').submit();
                }
            })
            @else
            Swal.fire({
                title: '¿Estas Seguro?',
                text: "Marcarás este pedido como No Enviado/Retirado",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Si, ¡Estoy seguro!'
            }).then((result) => {
                if (result.isConfirmed) {
                    
                    $('#formulario').submit();
                }
            })
            @endif
        })
    </script>
@endsection