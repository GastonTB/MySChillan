<div>
    <div class="flex ml-5 mb-5 space-x-1">
        <div class="">
            <p class="text-2xl lg:text-xl font-black">
                Ultimos Productos
            </p>
        </div>
        <div class="flex">
            <div class="cursor-pointer py-1 mx-1 px-1 bg-gray-200 rounded-md shadow-sm hover:bg-lime-500">
                <i id="ultimos-izquierda" class="fa fa-chevron-left"></i>
            </div>
            <div class="cursor-pointer py-1 px-1 bg-gray-200 rounded-md shadow-sm hover:bg-lime-500">
                <i id ="ultimos-derecha" class="fa fa-chevron-right"></i>
            </div>
        </div>
    </div>
    <div class="swiper ml-5" id="ultimos-mobile">
        <div class="swiper-wrapper">
            <?php
                $contador = 0;
                $contador2 = 0;
            ?>
            <div class="swiper-slide space-y-3">  
                <?php $__currentLoopData = $ultimos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ultimo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php if($contador == 3): ?>
                            <?php break; ?>
                        <?php endif; ?>
                        <div>
                            <a href="<?php echo e(route('detalles', $ultimo->id)); ?>">
                                <div class="flex">
                                    <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$ultimo->imagenes)); ?>"  alt="">
                                    <ul>
                                        <li>
                                            <p class="ml-3">
                                                <?php echo e($ultimo->nombre_producto); ?>

                                            </p>
                                        </li>
                                        <li>
                                            <p class="ml-3 font-semibold">
                                                $<?php echo e(number_format($ultimo->precio, 0, ",", ".")); ?>

                                            </p>
                                        </li>
                                    </ul>
                                </div>
                            </a>
                        </div>
                        <?php
                            $contador++;
                        ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-slide space-y-3">  
                <?php $__currentLoopData = $ultimos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ultimo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php if($contador2 > 3): ?>
                        <div>
                            <a href="<?php echo e(route('detalles', $ultimo->id)); ?>">
                                <div class="flex">
                                    <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$ultimo->imagenes)); ?>"  alt="">
                                    <ul>
                                        <li>
                                            <p class="ml-3">
                                                <?php echo e($ultimo->nombre_producto); ?>

                                            </p>
                                        </li>
                                        <li>
                                            <p class="ml-3 font-semibold">
                                                $<?php echo e(number_format($ultimo->precio, 0, ",", ".")); ?>

                                            </p>
                                        </li>
                                    </ul>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                        
                        <?php
                            $contador2++;
                        ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\MySPlantas\resources\views/components/slider-ultimos-productos.blade.php ENDPATH**/ ?>