<div>
    <div class="flex ml-5 mb-5 space-x-5">
        <div clas="justify-start">
            <p class="text-2xl font-black">Ofertas</p>
        </div>
        <div class="flex justify-end">
            <div id="oferta-izquierda" class="py-1 mx-1 px-1 bg-gray-200 shadow-sm rounded-md hover:bg-lime-500">
                <i class="fa fa-chevron-left"></i>
            </div>
            <div id="oferta-derecha" class="py-1 px-1 bg-gray-200 shadow-sm rounded-md hover:bg-lime-500">
                <i class="fa fa-chevron-right"></i>
            </div>
        </div>
    </div>
    <div class="swiper ml-5" id="ofertas-slider">
        <div class="swiper-wrapper">
            <?php
                $contador = 0;
                $contador2 = 0;
                $contador3 = 0;
                $cantidad_ofertas = count($ofertas); 
            ?>
            <?php if($cantidad_ofertas < 4): ?>
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide space-y-3">
                        <a href="<?php echo e(route('detalles', $oferta->id)); ?>">
                            <div class="flex">
                                <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$oferta->imagenes[0])); ?>"  alt="">
                                <ul>
                                    <li>
                                        <p class="ml-3">
                                            <?php echo e($oferta->nombre_producto); ?>

                                        </p>
                                    </li>
                                    <li>
                                        <p class="ml-3 font-semibold">
                                            $<?php echo e(number_format($oferta->oferta->precio_oferta, 0, ",", ".")); ?>

                                        </p>
                                    </li>
                                    <li>
                                        <p class="ml-3 text-sm line-through text-gray-600">
                                            $<?php echo e(number_format($oferta->precio, 0, ",", ".")); ?>

                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($cantidad_ofertas >= 3 && $cantidad_ofertas < 6): ?>
             <div class="swiper-slide space-y-3">
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($contador == 2): ?>
                        <?php break; ?>
                    <?php endif; ?>
                        <div>
                            <a href="<?php echo e(route('detalles', $oferta->id)); ?>">
                                <div class="flex">
                                    <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$oferta->imagenes[0])); ?>"  alt="">
                                    <ul>
                                        <li>
                                            <p class="ml-3">
                                                <?php echo e($oferta->nombre_producto); ?>

                                            </p>
                                        </li>
                                        <li>
                                            <p class="ml-3 font-semibold">
                                                $<?php echo e(number_format($oferta->oferta->precio_oferta, 0, ",", ".")); ?>

                                            </p>
                                        </li>
                                        <li>
                                            <p class="ml-3 text-sm line-through text-gray-600">
                                                $<?php echo e(number_format($oferta->precio, 0, ",", ".")); ?>

                                            </p>
                                        </li>
                                    </ul>
                                </div>
                            </a>
                        </div>
                    
                    <?php
                        $contador++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-slide space-y-3">
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($contador2 >= 2 && $contador2 < 4 ): ?>
                    <div>
                        <a href="<?php echo e(route('detalles', $oferta->id)); ?>">
                            <div class="flex">
                                <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$oferta->imagenes[0])); ?>"  alt="">
                                <ul>
                                    <li>
                                        <p class="ml-3">
                                            <?php echo e($oferta->nombre_producto); ?>

                                        </p>
                                    </li>
                                    <li>
                                        <p class="ml-3 font-semibold">
                                            $<?php echo e(number_format($oferta->oferta->precio_oferta, 0, ",", ".")); ?>

                                        </p>
                                    </li>
                                    <li>
                                        <p class="ml-3 text-sm line-through text-gray-600">
                                            $<?php echo e(number_format($oferta->precio, 0, ",", ".")); ?>

                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </a>
                    </div>
                    <?php else: ?>
                        
                    <?php endif; ?>
                    
                    <?php
                        $contador2++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-slide space-y-3">
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($contador3 >= 4 ): ?>
                    <div>
                        <a href="<?php echo e(route('detalles', $oferta->id)); ?>">
                            <div class="flex">
                                <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$oferta->imagenes[0])); ?>"  alt="">
                                <ul>
                                    <li>
                                        <p class="ml-3">
                                            <?php echo e($oferta->nombre_producto); ?>

                                        </p>
                                    </li>
                                    <li>
                                        <p class="ml-3 font-semibold">
                                            $<?php echo e(number_format($oferta->oferta->precio_oferta, 0, ",", ".")); ?>

                                        </p>
                                    </li>
                                    <li>
                                        <p class="ml-3 text-sm line-through text-gray-600">
                                            $<?php echo e(number_format($oferta->precio, 0, ",", ".")); ?>

                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <?php
                        $contador3++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
                <div class="swiper-slide space-y-3">  
                    <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php if($contador == 3): ?>
                                <?php break; ?>
                            <?php endif; ?>
                            <div>
                                <a href="<?php echo e(route('detalles', $oferta->id)); ?>">
                                    <div class="flex">
                                        <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$oferta->imagenes[0])); ?>"  alt="">
                                        <ul>
                                            <li>
                                                <p class="ml-3">
                                                    <?php echo e($oferta->nombre_producto); ?>

                                                </p>
                                            </li>
                                            <li>
                                                <p class="ml-3 font-semibold">
                                                    $<?php echo e(number_format($oferta->oferta->precio_oferta, 0, ",", ".")); ?>

                                                </p>
                                            </li>
                                            <li>
                                                <p class="ml-3 text-sm line-through text-gray-600">
                                                    $<?php echo e(number_format($oferta->precio, 0, ",", ".")); ?>

                                                </p>
                                            </li>
                                        </ul>
                                    </div>
                                </a>
                            </div>
                            <?php
                                $contador++;
                            ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="swiper-slide space-y-3">  
                    <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php if($contador2 > 3): ?>
                            <div>
                                <a href="<?php echo e(route('detalles', $oferta->id)); ?>">
                                    <div class="flex">
                                        <img class="h-32 rounded-sm" src="<?php echo e(asset('storage/imagenes/'.$oferta->imagenes[0])); ?>"  alt="">
                                        <ul>
                                            <li>
                                                <p class="ml-3">
                                                    <?php echo e($oferta->nombre_producto); ?>

                                                </p>
                                            </li>
                                            <li>
                                                <p class="ml-3 font-semibold">
                                                    $<?php echo e(number_format($oferta->oferta->precio_oferta, 0, ",", ".")); ?>

                                                </p>
                                            </li>
                                            <li>
                                                <p class="ml-3 text-sm line-through text-gray-600">
                                                    $<?php echo e(number_format($oferta->precio, 0, ",", ".")); ?>

                                                </p>
                                            </li>
                                        </ul>
                                    </div>
                                </a>
                            </div>
                            <?php endif; ?>
                            
                            <?php
                                $contador2++;
                            ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\MySPlantas\resources\views/components/slider-ofertas.blade.php ENDPATH**/ ?>