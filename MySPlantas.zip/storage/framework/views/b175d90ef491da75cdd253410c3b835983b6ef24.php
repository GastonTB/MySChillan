<div class="border-1 rounded-md bg-gray-100 shadow-md">
    <form action="<?php echo e(route('filtrar')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="py-5">
            <p class="text-xl ml-5 mb-5 font-black text-lime-500">Filtrar por Categorias</p>
            
            <ul class="mx-5 border-1 rounded-md px-5 pb-5 bg-white" id="categorias2">
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" 
                        value="1" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 1): ?>
                            checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox" >
                        <label class="form-check-label inline-block text-gray-800">
                          Ornamentales
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="2" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 2): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox" >
                        <label class="form-check-label inline-block text-gray-800">
                          Plantas de Interior
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="3" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 3): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox" >
                        <label class="form-check-label inline-block text-gray-800">
                          Plantas de Exterior
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="4" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 4): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox"  >
                        <label class="form-check-label inline-block text-gray-800">
                          Suculentas
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="5" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 5): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox">
                        <label class="form-check-label inline-block text-gray-800">
                          Árboles Frutales
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="6" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 6): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="form-check-input categorias rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150  appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox">
                        <label class="form-check-label inline-block text-gray-800">
                          Maceteros
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="7" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 7): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox"  >
                        <label class="form-check-label inline-block text-gray-800">
                          Tierra de Hojas
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="8" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 8): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox"  >
                        <label class="form-check-label inline-block text-gray-800">
                          Accesorios
                        </label>
                    </div>
                </li>
                <li class="py-2 hover:text-lime-500">
                    <div class="form-check">
                        <input name="categorias[]" value="9" 
                        <?php if( ! empty($categoria)): ?>
                            <?php if($categoria == 9): ?>
                                checked
                            <?php endif; ?>
                        <?php endif; ?>
                        class="rounded-md hover:bg-lime-500 hover:animate-ping ease-in-out delay-150 categorias form-check-input appearance-none h-4 w-4 border border-gray-300 bg-white checked:bg-green-500 focus:outline-none transition duration-200 mt-1 align-top bg-no-repeat bg-center bg-contain float-left mr-2 cursor-pointer" type="checkbox"  >
                        <label class="form-check-label inline-block text-gray-800">
                          Todos
                        </label>
                    </div>
                </li>

            </ul>
            <span class="text-sm ml-5" style="color:red"><small><?php $__errorArgs = ['categorias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></small></span>                                                           

        <div class="flex justify-center lg:justify-start lg:ml-5">
            <button type="submit" class="btn-primary">
                <p>Filtrar</p>
            </button>
        </div>
        </div>
    </form>
</div><?php /**PATH C:\xampp\htdocs\MySPlantas\resources\views/components/filtro-categorias.blade.php ENDPATH**/ ?>