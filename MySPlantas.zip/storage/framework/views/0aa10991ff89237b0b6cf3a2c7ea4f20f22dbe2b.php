

<?php $__env->startSection('content'); ?>
    <div class="lg:grid lg:grid-cols-5 mt-10">
        <div class="lg:grid lg:col-start-2 lg:col-span-3">
            <div class="md:grid md:grid-cols-3 gap-3">
                <div>
                    <div class=" py-5">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.crud-productos','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('crud-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
                <div>
                    <div class=" py-5">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.crud-ofertas','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('crud-ofertas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="lg:flex lg:items-center lg:justify-center py-5">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.crud-usuarios','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('crud-usuarios'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div> 
            </div>
            <div class="md:grid md:grid-cols-3">
              <div class="">
                <div class="flex justify-center">
                    <p class="font-semibold text-xl">
                        Ultimas Ventas
                    </p>
                </div>
                  <table class="border-2">
                        <thead class="bg-lime-500 text-white font-semibold">
                            <tr>
                                <th class="px-4 py-2">Fecha</th>
                                <th class="px-4 py-2">Total</th>
                                <th class="px-4 py-2">Tipo de Envio</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b">
                                    <td class=" px-4 py-2">
                                        <?php echo e(date('d-m-Y', strtotime($orden->created_at))); ?>

                                    </td>
                                    <td class=" px-4 py-2">
                                        $<?php echo e(number_format($orden->total, 0, ',', '.')); ?>

                                    </td>
                                    <td class=" px-4 py-2">
                                        <?php if($orden->envio == 1): ?>
                                            Envio a Domicilio
                                        <?php else: ?>
                                            Retiro en Tienda
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                  </table>
              </div>
              <div class="">
                <div class="flex justify-center">
                    <p class="font-semibold text-xl">
                        Ultimas Ofertas
                    </p>
                </div>
                  <table class="border-2">
                        <thead class="bg-lime-500 text-white font-semibold">
                            <tr>
                                <th class="px-4 py-2">Producto</th>
                                <th class="px-4 py-2">Fecha Inicio</th>
                                <th class="px-4 py-2">Fecha Fin</th>
                                <th class="px-4 py-2">Precio Original</th>
                                <th class="px-4 py-2">Precio Oferta</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orden; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b">
                                    <td class=" px-4 py-2">
                                    </td>
                                    <td class=" px-4 py-2">
                                    </td>
                                    <td class=" px-4 py-2">
                                       
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                  </table>
                </div>
              <div class="lg:flex lg:items-center lg:justify-center px-5 py-5">
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.crud-usuarios','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('crud-usuarios'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
              </div> 
          </div>
            <div class="md:grid lg:grid-cols-3 md:grid-cols-2 space-x-3">   
                <div class="border-2">
                    <div class="flex justify-center mb-3">
                        <p class="text-lg font-bold text-gray-700">Cantidad de unidades en Stock</p>
                    </div>
                    <div>
                        <canvas id="myChart"></canvas>
                    </div>
                </div>
                <div class="border-2">
                    <div class="grid grid-cols-1 items-end">
                        <div class="flex justify-center mb-3">
                            <p class="text-lg font-bold text-gray-700">Productos por Categoria en Stock</p>
                        </div>
                        
                        <div class="grid ">
                            <canvas id="myChart2"></canvas>
                        </div>
                    </div>
                </div>
                <div class="border-2">
                    <div class="flex justify-center mb-3">
                        <p class="text-lg font-bold text-gray-700">Total Productos por Categoria en Stock</p>
                    </div>
                    <div class="grid items-end">
                        <canvas id="myChart3"></canvas>
                    </div>
                </div>
            </div>
            <div class="md:grid lg:grid-cols-3 md:grid-cols-2">   
                <div class="p-5">
                    <?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = App\View\Components\Slider::resolve(['nombre' => 'Más Vendidos'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>                
                </div>
                <div class="p-5">
                    <?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = App\View\Components\Slider::resolve(['nombre' => 'Mejor Calificados'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>
                </div>
                <div class="p-5">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-ofertas','data' => ['ofertas' => $ofertas]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-ofertas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ofertas' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ofertas)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.0.1/dist/chart.umd.min.js"></script>

    <script>
        var swiper6 = new Swiper("#ofertas-slider", {
                slidesPerView: 1,
                spaceBetween: 10,
                slidesPerGroup: 1,
                loop: true,
                loopFillGroupWithBlank: true,
                navigation: {
                nextEl: "#oferta-derecha",
                prevEl: "#oferta-izquierda",
                },
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                }
                });

        const ctx = document.getElementById('myChart');
        var productos = [];
        var cantidad = [];
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            productos.push("<?php echo e($producto->nombre_producto); ?>");
            cantidad.push("<?php echo e($producto->cantidad); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        new Chart(ctx, {
          type: 'pie',
          data: {

            labels: productos,
            datasets: [{
              label: 'Unidades',
              data: cantidad,
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              
            }
          }
        });

        const ctx2 = document.getElementById('myChart2');
        var categorias = [];
        var cantidad2 = [];
        <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            categorias.push("<?php echo e($categoria->nombre_categoria); ?>");
            cantidad2.push("<?php echo e($categoria->productos); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        new Chart(ctx2, {
            type: 'bar',
          data: {
            labels: categorias,
            datasets: [{
              label: 'Productos',
              data: cantidad2,
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 10
                }
              }
            }
          }
        });

        const ctx3 = document.getElementById('myChart3');
        var categorias2= [];
        var cantidad3 = [];
        <?php $__currentLoopData = $array2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            categorias2.push("<?php echo e($categoria2->nombre_categoria); ?>");
            cantidad3.push("<?php echo e($categoria2->productos); ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        new Chart(ctx3, {
            type: 'bar',
          data: {
            labels: categorias2,
            datasets: [{
              label: 'Productos',
              data: cantidad3,
              borderWidth: 1
            }]
          },
          options: {
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 100
                }
              }
              
            }
          }
        });

      </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MySPlantas\resources\views/back-office.blade.php ENDPATH**/ ?>