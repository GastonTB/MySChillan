

<?php $__env->startSection('content'); ?>
    <div class="lg:grid lg:grid-cols-5 mt-10">
        <div class="lg:grid lg:col-start-2 lg:col-span-3">
            <div class="md:grid md:grid-cols-3">
                <div>
                    <div class="px-5 py-5">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.crud-productos','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('crud-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
                <div>
                    <div class="px-5 py-5">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.crud-ofertas','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('crud-ofertas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="lg:flex lg:items-center lg:justify-center px-5 py-5">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.crud-usuarios','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('crud-usuarios'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div> 
            </div>
            <div class="md:grid lg:grid-cols-3 md:grid-cols-2">
                
                <div class="p-5">
                    <?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = App\View\Components\Slider::resolve(['nombre' => 'Más Vendidos'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>                
                </div>
                <div class="p-5">
                    <?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = App\View\Components\Slider::resolve(['nombre' => 'Mejor Calificados'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>
                </div>
                <div class="p-5">
                    <?php if (isset($component)) { $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee = $component; } ?>
<?php $component = App\View\Components\Slider::resolve(['nombre' => 'Ofertas Vigentes'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee)): ?>
<?php $component = $__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee; ?>
<?php unset($__componentOriginal01b4f1dbbb3b5a01d5176c6f051164cd2951e8ee); ?>
<?php endif; ?>
                </div>
            
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MySPlantas\resources\views/back-office.blade.php ENDPATH**/ ?>