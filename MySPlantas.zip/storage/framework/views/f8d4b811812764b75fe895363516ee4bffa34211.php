<div>
    <div class="swiper" id="producto">
        <div class="swiper-wrapper">
            <?php for($i = 0; $i < count($producto->imagenes);$i++): ?>
                <div class="swiper-slide">                  
                    <div class="flex justify-center">
                        <img class="" src="<?php echo e(asset('storage/imagenes/'.$producto->imagenes[$i])); ?>"  alt="">
                    </div>
                </div>
            <?php endfor; ?>
        </div>
        <div class="text-lime-500 swiper-pagination"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\MySPlantas\resources\views/components/slider-fotos-producto.blade.php ENDPATH**/ ?>