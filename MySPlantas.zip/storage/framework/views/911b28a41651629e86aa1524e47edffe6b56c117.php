

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-3 mt-10">
    <div class="col-start-2 col-span-1 flex justify-center">
        Pagando...
    </div>
</div>
<form name="pagar" method="POST" action="<?php echo e($datos->url); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="token_ws" value="<?php echo e($datos->token); ?>">
</form>

<?php $__env->startSection('js'); ?>
<script>
    window.onload = function() {
        document.pagar.submit();
    };
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MySPlantas\resources\views/webpay/pagar.blade.php ENDPATH**/ ?>