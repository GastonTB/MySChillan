<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Carrito;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\Models\UserMetadata;
use App\Models\Comuna;
use App\Models\Region;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\Producto;
use App\Models\Oferta;
use App\Models\OrdenCompra;


class compraController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {   
        if(Auth::check()){
            $carrito = Carrito::where('user_id', Auth::user()->id)->get();
            if($carrito->isEmpty()){
                return redirect()->route('home');
            }
            $user = User::findOrFail(Auth::user()->id);
            $user = $user;
            $meta = UserMetadata::where('user_id', $user->id)->first();
            $comuna_user = Comuna::findOrFail($meta->comuna_id);
            $region_user = Region::findOrFail($comuna_user->region_id); 

        }else{
            Alert::html('Debes iniciar sesión para continuar', '<button id="boton-login" class="btn-tienda" href="">Iniciar sesión</button>');
            return redirect()->back();
        }

        
        return view('compra.show', compact('carrito', 'user', 'meta', 'region_user', 'comuna_user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function detalle($id){
        $ordenCompra = OrdenCompra::where('id', $id)->where('estado',1)->first();

        //trycatch
        if($ordenCompra == null){
            Alert::error('Error', 'No se encontró la orden de compra');
            return redirect()->route('inicio');
        }

        $usuario = $ordenCompra->user;
        //trycatch
        if($usuario == null){
            Alert::error('Error', 'No se encontró el usuario');
            return redirect()->route('inicio');
        }
        $meta = $usuario->userMetadata;
        //trycatch
        if($meta == null){
            Alert::error('Error', 'No se encontró la metadata del usuario');
            return redirect()->route('inicio');
        }
        $comuna = $meta->comuna;
        //trycatch
        if($comuna == null){
            Alert::error('Error', 'No se encontró la comuna del usuario');
            return redirect()->route('inicio');
        }
        $region = $comuna->region;
        //trycatch
        if($region == null){
            Alert::error('Error', 'No se encontró la región del usuario');
            return redirect()->route('inicio');
        }
        $productos = $ordenCompra->productos;
        //trycatch
        if($productos == null){
            Alert::error('Error', 'No se encontró los productos de la orden de compra');
            return redirect()->route('inicio');
        }
        

        return view('compra.detalle', compact('ordenCompra', 'usuario' ,'meta', 'comuna', 'region', 'productos'));
    }

    public function cambiarEstado($id){
        $ordenCompra = OrdenCompra::where('id', $id)->where('estado',1)->first();

        //trycatch
        if($ordenCompra == null){
            Alert::error('Error', 'No se encontró la orden de compra');
            return redirect()->route('inicio');
        }

        if($ordenCompra->estado_retiro == 0){
            $ordenCompra->estado_retiro = 1;
            $ordenCompra->save();
            Alert::success('Éxito', 'Se ha Enviado/Retirado esta Compra');

        }else{
            $ordenCompra->estado_retiro = 0;
            $ordenCompra->save();
            Alert::success('Éxito', 'Se ha Cancelado el Envío/Retiro de esta Compra');
        }

        return redirect()->route('compra', $ordenCompra->id);
      

    }
}
